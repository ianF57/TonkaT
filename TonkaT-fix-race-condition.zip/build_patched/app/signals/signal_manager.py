"""Signal manager — DB-only data access via HistoricalDataStore."""
from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Any

from app.data.historical_store import HistoricalDataStore, InsufficientDataError
from app.regime.regime_classifier import RegimeClassifier
from app.signals.base_signal import SignalCandidate
from app.signals.breakout_v1 import BreakoutV1
from app.signals.mean_reversion_v1 import MeanReversionV1
from app.signals.trend_signal_v1 import TrendSignalV1

logger = logging.getLogger(__name__)

_SIGNALS_LIMIT = 250   # candles loaded for signal generation


class SignalManager:
    """Generate and rank candidate strategy signals from stored historical data.

    Data source: local SQLite candle table (HistoricalDataStore).
    No external API calls are made.
    """

    def __init__(self) -> None:
        self.store = HistoricalDataStore()
        self.regime_classifier = RegimeClassifier()
        self.strategies = [
            TrendSignalV1(),
            MeanReversionV1(),
            BreakoutV1(),
        ]

    async def generate_signals(self, asset: str, timeframe: str = "1h") -> dict[str, Any]:
        """Generate signals from the most-recent stored candles.

        *asset* must be a canonical bare symbol (e.g. ``"BTCUSDT"``), as
        returned by :func:`~app.api.asset_validation.validate_asset_path`.
        The symbol is queried directly against the ``candle`` table — no
        provider-prefix stripping is performed here.

        Raises InsufficientDataError when the DB has < MINIMUM_CANDLES rows.
        """
        # asset is already the canonical bare symbol after validate_asset_path().
        symbol = asset.strip().upper()

        logger.info(
            "generate_signals: querying symbol=%s timeframe=%s limit=%d",
            symbol,
            timeframe,
            _SIGNALS_LIMIT,
        )

        # DB-only: raises InsufficientDataError if not enough history
        candles = self.store.get_candles(symbol, timeframe, limit=_SIGNALS_LIMIT)

        regime_snapshot = self.regime_classifier.classify(
            candles, asset=symbol, timeframe=timeframe
        )

        candidates: list[SignalCandidate] = []
        for strategy in self.strategies:
            candidate = strategy.generate(
                asset=symbol,
                timeframe=timeframe,
                ohlcv=candles,
                regime=regime_snapshot.current_regime,
            )
            if candidate is not None:
                candidates.append(candidate)

        ranked = sorted(candidates, key=lambda c: c.performance_score, reverse=True)
        return {
            "asset":            symbol,
            "timeframe":        timeframe,
            "source":           "database",
            "candles_used":     len(candles),
            "regime":           regime_snapshot.current_regime,
            "confidence_score": regime_snapshot.confidence_score,
            "signals":          [asdict(s) for s in ranked],
            "signal_count":     len(ranked),
        }
